package prgram6CaHap04;

public class Parent {
 String name = "영조";
 void print () {
	 System.out.println("나는 조선 의 21대 국왕이다.");
 }
}
