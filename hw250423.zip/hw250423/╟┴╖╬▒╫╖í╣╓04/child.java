package prgram6CaHap04;

public class child  extends Parent{
 String name = "사도세자";
 
 void print() {
	 System.out.println("나는"+name+"이다.");
 }
}
