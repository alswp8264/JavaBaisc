package prgram6CaHap03;

public class PointTest {
    public static void main(String[] args) {
	      Point t = new Point(3, 4);
	      Point t2 = new MovablePoint(4, 5, 10, 12);
	      System.out.println(t.toString());
	      System.out.println(t2.toString());
		}
}
