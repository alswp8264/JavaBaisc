package java250423;

public class CircleTest {
 public static void main(String[]args) {
	 Circle c = new Circle(5);
	 Circle c2 = new ColoredCircle(10, " 빨간색");
	 c.show();
	 c2.show();
 }
}
