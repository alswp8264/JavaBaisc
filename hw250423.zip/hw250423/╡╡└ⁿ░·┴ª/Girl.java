package java0423;

public class Girl {
  protected String name;
  
public Girl(String name) {
	this.name = name;  
  }
  void show() {
	  System.out.println(name +"는 자바 초보이다.");
  }
  
}
